import { useState, useMemo } from 'react'

interface Vehicle {
  id: number
  plate: string
  info: string
  site: string
  inspectionDate: string
  exhaustDate: string
  note: string
}

const vehiclesData: Vehicle[] = [
  { id: 1, plate: '22 AEJ 005', info: 'Ford Transit Custom', site: 'KEŞAN', inspectionDate: '06.02.2027', exhaustDate: '06.02.2027', note: '' },
  { id: 2, plate: '22 AEJ 472', info: 'Ford Çekici F-MAX', site: 'KIRKLARELİ', inspectionDate: '', exhaustDate: '', note: '' },
  { id: 3, plate: '22 AEJ 480', info: 'Ford Çekici F-MAX', site: 'KIRKLARELİ', inspectionDate: '', exhaustDate: '', note: '' },
  { id: 4, plate: '22 AEJ 904', info: 'Ford Çekici F-MAX', site: 'KIRKLARELİ', inspectionDate: '', exhaustDate: '', note: '' },
  { id: 5, plate: '22 RB 149', info: 'Ford Transit', site: 'EDİRNE', inspectionDate: '28.09.2026', exhaustDate: '02.09.2026', note: '' },
  { id: 6, plate: '22 AAF 004', info: 'MİKSER', site: 'EDİRNE', inspectionDate: '25.06.2026', exhaustDate: '24.06.2026', note: '' },
  { id: 7, plate: '22 AAF 007', info: 'MİKSER', site: 'KEŞAN', inspectionDate: '16.07.2026', exhaustDate: '24.06.2026', note: '' },
  { id: 8, plate: '22 AAF 011', info: 'MİKSER', site: 'KEŞAN', inspectionDate: '25.08.2026', exhaustDate: '03.07.2026', note: '' },
  { id: 9, plate: '22 AAF 013', info: 'MİKSER', site: 'EDİRNE', inspectionDate: '09.07.2026', exhaustDate: '10.06.2026', note: '' },
  { id: 10, plate: '22 AAF 024', info: 'MİKSER', site: 'KIRKLARELİ', inspectionDate: '24.07.2026', exhaustDate: '22.06.2026', note: '' },
  { id: 11, plate: '22 ABP 769', info: 'Fiat Doblo / BEYAZ', site: 'KIRKLARELİ', inspectionDate: '04.01.2027', exhaustDate: '04.01.2027', note: '' },
  { id: 12, plate: '22 ABP 770', info: 'Fiat Doblo', site: 'EDİRNE', inspectionDate: '09.01.2027', exhaustDate: '09.01.2027', note: '' },
  { id: 13, plate: '22 ABR 383', info: 'MİKSER', site: 'EDİRNE', inspectionDate: '11.02.2027', exhaustDate: '11.02.2027', note: '' },
  { id: 14, plate: '22 ABR 388', info: 'MİKSER', site: 'EDİRNE', inspectionDate: '17.03.2027', exhaustDate: '06.03.2027', note: '' },
  { id: 15, plate: '22 ABR 398', info: 'MİKSER', site: 'EDİRNE', inspectionDate: '10.04.2027', exhaustDate: '10.04.2027', note: '' },
  { id: 16, plate: '22 ABR 414', info: 'MİKSER', site: 'EDİRNE', inspectionDate: '09.02.2027', exhaustDate: '', note: '' },
  { id: 17, plate: '22 ABR 417', info: 'MİKSER', site: 'EDİRNE', inspectionDate: '10.02.2027', exhaustDate: '09.02.2027', note: '' },
  { id: 18, plate: '22 ABR 422', info: 'MİKSER', site: 'EDİRNE', inspectionDate: '27.02.2027', exhaustDate: '25.02.2027', note: '' },
  { id: 19, plate: '22 ACU 518', info: 'Mercedes Actros Çekici', site: 'KEŞAN', inspectionDate: '20.05.2026', exhaustDate: '15.04.2027', note: '' },
  { id: 20, plate: '22 ACY 381', info: 'Mercedes Actros Çekici', site: 'KEŞAN', inspectionDate: '08.05.2027', exhaustDate: '14.05.2026', note: '' },
  { id: 21, plate: '22 ADT 965', info: 'RENAULT CLİO', site: 'KEŞAN', inspectionDate: 'yok', exhaustDate: 'yok', note: '' },
  { id: 22, plate: '22 AEE 295', info: 'Fiat Fiorino', site: 'KEŞAN', inspectionDate: '', exhaustDate: '', note: '' },
  { id: 23, plate: '22 AEE 296', info: 'Fiat Fiorino', site: 'KIRKLARELİ', inspectionDate: '02.07.2026', exhaustDate: '02.07.2026', note: '' },
  { id: 24, plate: '22 AEE 297', info: 'Fiat Fiorino', site: 'KEŞAN', inspectionDate: '', exhaustDate: '', note: '' },
  { id: 25, plate: '22 AEE 298', info: 'Fiat Fiorino', site: 'KEŞAN', inspectionDate: '12.06.2026', exhaustDate: '11.06.2026', note: '' },
  { id: 26, plate: '59 AB 435', info: 'KAMYON', site: 'KEŞAN', inspectionDate: '12.03.2027', exhaustDate: '', note: '' },
  { id: 27, plate: '59 AB 436', info: 'Ford Cargo VİNÇ', site: 'KEŞAN', inspectionDate: '5.11.2026', exhaustDate: '', note: '' },
  { id: 28, plate: '59 ADM 141', info: 'POMPA', site: 'EDİRNE', inspectionDate: '9.12.2026', exhaustDate: '', note: '' },
  { id: 29, plate: '59 ADN 845', info: 'FORD TRANSİT SERVİS', site: 'EDİRNE', inspectionDate: '24.03.2027', exhaustDate: '', note: '' },
  { id: 30, plate: '59 ADU 630', info: 'POMPA', site: 'KIRKLARELİ', inspectionDate: '', exhaustDate: '', note: '' },
  { id: 31, plate: '59 AHA 786', info: 'MİKSER', site: 'KEŞAN', inspectionDate: '28.01.2027', exhaustDate: '', note: '' },
  { id: 32, plate: '59 AHN 258', info: 'FORD TRANSIT', site: 'KEŞAN', inspectionDate: '12.06.2026', exhaustDate: '', note: '' },
  { id: 33, plate: '59 AIA 360', info: 'Renault Clio Joy', site: 'EDİRNE', inspectionDate: 'yok', exhaustDate: '', note: '' },
  { id: 34, plate: '59 AIF 109', info: 'Mercedes Actros Çekici', site: 'EDİRNE', inspectionDate: '', exhaustDate: '', note: '' },
  { id: 35, plate: '59 AIF 116', info: 'Mercedes Actros Çekici', site: 'EDİRNE', inspectionDate: '15.09.2026', exhaustDate: '', note: '' },
  { id: 36, plate: '59 ALJ 157', info: 'Ford Çekici F-MAX', site: 'KEŞAN', inspectionDate: '23.01.2027', exhaustDate: '', note: '' },
  { id: 37, plate: '59 ALJ 207', info: 'Ford Çekici F-MAX', site: 'EDİRNE', inspectionDate: '22.01.2027', exhaustDate: '', note: '' },
  { id: 38, plate: '59 ALL 503', info: 'Mercedes Axor ÇEKİCİ / BEYAZ', site: 'KEŞAN', inspectionDate: '11.12.2026', exhaustDate: '', note: '' },
  { id: 39, plate: '59 AOF 635', info: 'VOLVO POMPA 56LIK', site: 'EDİRNE', inspectionDate: '10.12.2026', exhaustDate: '', note: '' },
  { id: 40, plate: '59 APA 528', info: 'MİKSER', site: 'KIRKLARELİ', inspectionDate: '', exhaustDate: '', note: '' },
  { id: 41, plate: '59 APA 551', info: 'MİKSER', site: 'KIRKLARELİ', inspectionDate: '', exhaustDate: '', note: '' },
  { id: 42, plate: '59 APA 565', info: 'MİKSER', site: 'KIRKLARELİ', inspectionDate: '', exhaustDate: '', note: '' },
  { id: 43, plate: '59 DB 137', info: 'MİKSER', site: 'KEŞAN', inspectionDate: '28.09.2026', exhaustDate: '', note: '' },
  { id: 44, plate: '59 DB 921', info: 'MİKSER', site: 'KEŞAN', inspectionDate: '9.12.2026', exhaustDate: '', note: '' },
  { id: 45, plate: '59 DB 924', info: 'MİKSER', site: 'KEŞAN', inspectionDate: '7.12.2026', exhaustDate: '', note: '' },
  { id: 46, plate: '59 DG 639', info: 'POMPA', site: 'KEŞAN', inspectionDate: '11.01.2027', exhaustDate: '29.12.2026', note: '' },
  { id: 47, plate: '59 DG 892', info: 'Bmc PRO KEŞAN', site: 'KEŞAN', inspectionDate: '04.05.2027', exhaustDate: '05.04.2027', note: '' },
  { id: 48, plate: '59 EK 719', info: 'Mitsubishi L200', site: 'KIRCASALİH', inspectionDate: '30.09.2026', exhaustDate: '09.09.2026', note: '' },
  { id: 49, plate: '59 EP 729', info: 'Ford Cargo', site: 'KIRCASALİH', inspectionDate: '7.11.2026', exhaustDate: '15.12.2026', note: '' },
  { id: 50, plate: '59 KH 912', info: 'Bmc PRO', site: 'KIRCASALİH', inspectionDate: '19.04.2027', exhaustDate: '19.04.2027', note: '' },
  { id: 51, plate: '59 KL 294', info: 'MİKSER', site: 'KEŞAN', inspectionDate: '18.02.2027', exhaustDate: '20.01.2027', note: '' },
  { id: 52, plate: '59 KN 312', info: 'MİKSER', site: 'KEŞAN', inspectionDate: '13.05.2026', exhaustDate: '08.05.2027', note: '' },
  { id: 53, plate: '59 KN 314', info: 'MİKSER', site: 'KEŞAN', inspectionDate: '18.05.2026', exhaustDate: '14.05.2026', note: '' },
  { id: 54, plate: '59 KP 617', info: 'MİKSER', site: 'KEŞAN', inspectionDate: '02.09.2026', exhaustDate: '02.09.2026', note: '' },
  { id: 55, plate: '59 AIG 844', info: 'Daf Çekici Silobaz', site: 'EDİRNE', inspectionDate: '23.07.2026', exhaustDate: '23.07.2026', note: '' },
  { id: 56, plate: '59 AIG 847', info: 'Daf Çekici Silobaz', site: 'EDİRNE', inspectionDate: '04.09.2026', exhaustDate: '04.09.2026', note: '' },
  { id: 57, plate: '59 AJZ 295', info: 'MİKSER', site: 'KIRKLARELİ', inspectionDate: '18.07.2026', exhaustDate: '18.07.2026', note: '' },
  { id: 58, plate: '59 AJZ 301', info: 'MİKSER', site: 'KEŞAN', inspectionDate: '14.07.2026', exhaustDate: '14.07.2026', note: '' },
  { id: 59, plate: '59 AJZ 318', info: 'MİKSER', site: 'KIRKLARELİ', inspectionDate: '16.07.2026', exhaustDate: '16.07.2026', note: '' },
  { id: 60, plate: '59 AJZ 403', info: 'MİKSER', site: 'KIRKLARELİ', inspectionDate: '21.07.2026', exhaustDate: '21.07.2026', note: '' },
  { id: 61, plate: '59 AJZ 405', info: 'MİKSER', site: 'KEŞAN', inspectionDate: '23.07.2026', exhaustDate: '22.07.2026', note: '' },
  { id: 62, plate: '59 AKM 075', info: 'POMPA', site: 'KEŞAN', inspectionDate: '3.11.2026', exhaustDate: '9.10.2026', note: '' },
  { id: 63, plate: '59 AKM 621', info: 'DAF ÇEKİCİ TANKER', site: 'KEŞAN', inspectionDate: '24.06.2026', exhaustDate: '22.06.2026', note: '' },
  { id: 64, plate: '59 ALB 442', info: 'POMPA', site: 'KIRKLARELİ', inspectionDate: '07.01.2027', exhaustDate: '06.01.2027', note: '' },
  { id: 65, plate: '59 ALC 090', info: 'Ford Çekici F-MAX', site: 'EDİRNE', inspectionDate: '13.10.2026', exhaustDate: '13.10.2026', note: '' },
  { id: 66, plate: '59 ALC 092', info: 'Ford Tanker', site: 'KEŞAN', inspectionDate: '02.04.2027', exhaustDate: '30.09.2026', note: '' },
  { id: 67, plate: '59 ALC 511', info: 'Ford Çekici F-MAX', site: 'EDİRNE', inspectionDate: '16.10.2026', exhaustDate: '16.10.2026', note: '' },
  { id: 68, plate: '59 ALC 529', info: 'Ford Çekici F-MAX', site: 'KIRKLARELİ', inspectionDate: '10.10.2026', exhaustDate: '9.10.2026', note: '' },
  { id: 69, plate: '59 ALC 616', info: 'Ford Çekici F-MAX', site: 'KEŞAN', inspectionDate: '19.10.2026', exhaustDate: '19.10.2026', note: '' },
  { id: 70, plate: '59 ALC 627', info: 'Ford Çekici F-MAX', site: 'KEŞAN', inspectionDate: '6.10.2026', exhaustDate: '6.10.2026', note: '' },
  { id: 71, plate: '59 ALE 312', info: 'Ford Çekici F-MAX', site: 'EDİRNE', inspectionDate: '24.10.2026', exhaustDate: '24.10.2026', note: '' },
  { id: 72, plate: '59 ALF 979', info: 'Ford Çekici F-MAX', site: 'EDİRNE', inspectionDate: '7.12.2026', exhaustDate: '7.12.2026', note: '' },
  { id: 73, plate: '59 ALH 051', info: 'Ford Çekici F-MAX SİLOBAZ', site: 'EDİRNE', inspectionDate: '7.12.2026', exhaustDate: '7.12.2026', note: '' },
  { id: 74, plate: '59 ALH 878', info: 'Ford Çekici F-MAX', site: 'KEŞAN', inspectionDate: '5.11.2026', exhaustDate: '5.11.2026', note: '' },
  { id: 75, plate: '34 BNB 911', info: 'Mercedes Actross POMPA', site: 'EDİRNE', inspectionDate: '', exhaustDate: '', note: '' },
  { id: 76, plate: '39 AEM 763', info: 'FORD TRANSİT SERVİS', site: 'KIRKLARELİ', inspectionDate: '', exhaustDate: '', note: '' },
]

function parseDate(dateStr: string): Date | null {
  if (!dateStr || dateStr.toLowerCase() === 'yok' || dateStr.trim() === '') return null
  const parts = dateStr.split('.')
  if (parts.length !== 3) return null
  const day = parseInt(parts[0])
  const month = parseInt(parts[1])
  const year = parseInt(parts[2])
  if (isNaN(day) || isNaN(month) || isNaN(year)) return null
  return new Date(year, month - 1, day, 0, 0, 0, 0)
}

function getDaysUntil(dateStr: string): number | null {
  const date = parseDate(dateStr)
  if (!date) return null
  
  const today = new Date()
  today.setHours(0, 0, 0, 0)
  
  const diffTime = date.getTime() - today.getTime()
  const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24))
  
  return diffDays
}

function getStatusColor(dateStr: string): string {
  const days = getDaysUntil(dateStr)
  if (days === null) return 'bg-gray-100 text-gray-600'
  if (days < 0) return 'bg-red-100 text-red-700'
  if (days <= 30) return 'bg-yellow-100 text-yellow-700'
  return 'bg-green-100 text-green-700'
}

function getStatusText(dateStr: string): string {
  const days = getDaysUntil(dateStr)
  if (days === null) return 'Belirtilmemiş'
  if (days < 0) return `${Math.abs(days)} gün geçti`
  if (days === 0) return 'Bugün'
  return `${days} gün kaldı`
}

function StatCard({ title, value, icon, color }: { title: string; value: number; icon: string; color: string }) {
  return (
    <div className={`${color} rounded-xl p-4 shadow-lg`}>
      <div className="flex items-center justify-between">
        <div>
          <p className="text-xs font-medium opacity-90">{title}</p>
          <p className="text-2xl font-bold mt-1">{value}</p>
        </div>
        <div className="text-3xl">{icon}</div>
      </div>
    </div>
  )
}

export default function App() {
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedSite, setSelectedSite] = useState('')
  const [sortBy, setSortBy] = useState<'id' | 'plate' | 'site' | 'inspectionDate'>('id')

  const sites = useMemo(() => {
    return [...new Set(vehiclesData.map(v => v.site))].sort()
  }, [])

  const filteredVehicles = useMemo(() => {
    return vehiclesData.filter(vehicle => {
      const matchesSearch = 
        vehicle.plate.toLowerCase().includes(searchTerm.toLowerCase()) ||
        vehicle.info.toLowerCase().includes(searchTerm.toLowerCase())
      const matchesSite = !selectedSite || vehicle.site === selectedSite
      return matchesSearch && matchesSite
    }).sort((a, b) => {
      if (sortBy === 'id') return a.id - b.id
      if (sortBy === 'plate') return a.plate.localeCompare(b.plate)
      if (sortBy === 'site') return a.site.localeCompare(b.site)
      if (sortBy === 'inspectionDate') {
        const dateA = parseDate(a.inspectionDate)
        const dateB = parseDate(b.inspectionDate)
        if (!dateA) return 1
        if (!dateB) return -1
        return dateA.getTime() - dateB.getTime()
      }
      return 0
    })
  }, [searchTerm, selectedSite, sortBy])

  const stats = useMemo(() => {
    const total = vehiclesData.length
    const withInspection = vehiclesData.filter(v => v.inspectionDate && v.inspectionDate !== 'yok').length
    const expiringSoon = vehiclesData.filter(v => {
      const days = getDaysUntil(v.inspectionDate)
      return days !== null && days >= 0 && days <= 30
    }).length
    const expired = vehiclesData.filter(v => {
      const days = getDaysUntil(v.inspectionDate)
      return days !== null && days < 0
    }).length
    return { total, withInspection, expiringSoon, expired }
  }, [])

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 pb-20">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200 sticky top-0 z-50">
        <div className="px-4 py-4">
          <div className="flex items-center gap-3">
            <div className="bg-blue-600 text-white p-2 rounded-lg">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01" />
              </svg>
            </div>
            <div>
              <h1 className="text-lg font-bold text-gray-900">Muayene Takip</h1>
              <p className="text-gray-500 text-xs">
                {new Date().toLocaleDateString('tr-TR', { day: 'numeric', month: 'long', year: 'numeric' })}
              </p>
            </div>
          </div>
        </div>
      </header>

      <main className="px-4 py-4">
        {/* Statistics */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
          <StatCard title="Toplam" value={stats.total} icon="🚗" color="bg-gradient-to-br from-blue-500 to-blue-600 text-white" />
          <StatCard title="Olan" value={stats.withInspection} icon="📋" color="bg-gradient-to-br from-green-500 to-green-600 text-white" />
          <StatCard title="30 Gün" value={stats.expiringSoon} icon="⚠️" color="bg-gradient-to-br from-yellow-500 to-yellow-600 text-white" />
          <StatCard title="Geçmiş" value={stats.expired} icon="🚨" color="bg-gradient-to-br from-red-500 to-red-600 text-white" />
        </div>

        {/* Filters */}
        <div className="bg-white rounded-xl shadow-lg p-4 mb-4">
          <div className="space-y-3">
            <div>
              <input
                type="text"
                placeholder="🔍 Plaka veya araç ara..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
              />
            </div>
            <div className="flex gap-2">
              <select
                value={selectedSite}
                onChange={(e) => setSelectedSite(e.target.value)}
                className="flex-1 px-3 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
              >
                <option value="">Tüm Şantiyeler</option>
                {sites.map(site => (
                  <option key={site} value={site}>{site}</option>
                ))}
              </select>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as typeof sortBy)}
                className="flex-1 px-3 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
              >
                <option value="id">Numara</option>
                <option value="plate">Plaka</option>
                <option value="inspectionDate">Tarih</option>
              </select>
            </div>
          </div>
        </div>

        {/* Results Count */}
        <p className="text-gray-600 text-sm mb-3">
          <span className="font-semibold">{filteredVehicles.length}</span> araç bulundu
        </p>

        {/* Vehicle Cards for Mobile */}
        <div className="space-y-3">
          {filteredVehicles.map((vehicle) => (
            <div key={vehicle.id} className="bg-white rounded-xl shadow-lg p-4">
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-2">
                  <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-bold bg-gray-800 text-white">
                    {vehicle.plate}
                  </span>
                  <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                    {vehicle.site}
                  </span>
                </div>
                <span className="text-xs text-gray-400">#{vehicle.id}</span>
              </div>
              <p className="text-sm text-gray-700 mb-3 font-medium">{vehicle.info}</p>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <p className="text-xs text-gray-500 mb-1">Muayene</p>
                  <div className="flex flex-col">
                    <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(vehicle.inspectionDate)}`}>
                      {vehicle.inspectionDate || '-'}
                    </span>
                    <span className="text-xs text-gray-500 mt-1">{getStatusText(vehicle.inspectionDate)}</span>
                  </div>
                </div>
                <div>
                  <p className="text-xs text-gray-500 mb-1">Egzoz</p>
                  <div className="flex flex-col">
                    <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(vehicle.exhaustDate)}`}>
                      {vehicle.exhaustDate || '-'}
                    </span>
                    <span className="text-xs text-gray-500 mt-1">{getStatusText(vehicle.exhaustDate)}</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Legend */}
        <div className="mt-6 bg-white rounded-xl shadow-lg p-4">
          <h3 className="text-sm font-semibold text-gray-900 mb-3">Renk Kodları</h3>
          <div className="flex flex-wrap gap-3">
            <div className="flex items-center gap-1">
              <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-700">
                ✓
              </span>
              <span className="text-xs text-gray-600">30+ gün</span>
            </div>
            <div className="flex items-center gap-1">
              <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-yellow-100 text-yellow-700">
                ⚠️
              </span>
              <span className="text-xs text-gray-600">30 gün</span>
            </div>
            <div className="flex items-center gap-1">
              <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-red-100 text-red-700">
                🚨
              </span>
              <span className="text-xs text-gray-600">Geçmiş</span>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 py-3 px-4">
        <p className="text-center text-gray-500 text-xs">
          Araç Muayene Takip © {new Date().getFullYear()}
        </p>
      </footer>
    </div>
  )
}
